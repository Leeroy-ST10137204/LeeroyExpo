﻿using System;

namespace RecipeApplication
{
    class Recipe
    {
        private string[] SUMofIngredients;
        private double[] quantitiesOfIngredients;
        private string[] units;
        private string[] steps;

        public Recipe()
        {
            // Initialize empty arrays for SUMofIngredients, quantitiesOfIngredients, units, and steps
            SUMofIngredients = new string[0];
            quantitiesOfIngredients = new double[0];
            units = new string[0];
            steps = new string[0];
        }

        public void EnterDetails()
        {
            // Prompt the user to enter the number of SUMofIngredients
            Console.Write("Enter the number of SUMofIngredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Initialize the arrays with the correct size
            SUMofIngredients = new string[numIngredients];
            quantitiesOfIngredients = new double[numIngredients];
            units = new string[numIngredients];

            // Prompt the user to enter the details for each ingredient
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter details for ingredient #{i + 1}:");
                Console.Write("Name: ");
                SUMofIngredients[i] = Console.ReadLine();
                Console.Write("Quantity: ");
                quantitiesOfIngredients[i] = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                units[i] = Console.ReadLine();
            }

            // Prompt the user to enter the number of steps
            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Initialize the steps array with the correct size
            steps = new string[numSteps];

            // Prompt the user to enter the details for each step
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step #{i + 1}: ");
                steps[i] = Console.ReadLine();
            }
        }

        public void DisplayRecipe()
        {
            // Display the SUMofIngredients and quantitiesOfIngredients
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < SUMofIngredients.Length; i++)
            {
                Console.WriteLine($"- {quantitiesOfIngredients[i]} {units[i]} of {SUMofIngredients[i]}");
            }

            // Display the steps
            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"- {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            // Multiply all the quantitiesOfIngredients by the scaling factor
            for (int i = 0; i < quantitiesOfIngredients.Length; i++)
            {
                quantitiesOfIngredients[i] *= factor;
            }
        }

        public void ResetQuantities()
        {
            // Reset all the quantitiesOfIngredients to their original values
            for (int i = 0; i < quantitiesOfIngredients.Length; i++)
            {
                quantitiesOfIngredients[i] /= 2;
            }
        }

        public void ClearRecipe()
        {
            // Reset all the arrays to empty
            SUMofIngredients = new string[0];
            quantitiesOfIngredients = new double[0];
            units = new string[0];
            steps = new string[0];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();
            while (true)
            {
                Console.WriteLine("Enter '1' to enter recipe details");
                Console.WriteLine("Enter '2' to display recipe");
                Console.WriteLine("Enter '3' to scale recipe");
                Console.WriteLine("Enter '4' to reset quantitiesOfIngredients");
                Console.WriteLine("Enter '5' to clear recipe");
                Console.WriteLine("Enter '6' to exit");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        recipe.EnterDetails();
                        break;
                    case "2":
                        recipe.DisplayRecipe();
                        break;
                    case "3":
                        Console.Write("Enter scaling factor (0.5, 2, or 3): ");
                        double factor = double.Parse(Console.ReadLine());
                        recipe.ScaleRecipe(factor);
                        break;
                    case "4":
                        recipe.ResetQuantities();
                        break;
                    case "5":
                        recipe.ClearRecipe();
                        break;
                    case "6":
                        Console.WriteLine("Exiting program...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a valid choice.");
                        break;
               
                }
            }
        }
    }
}